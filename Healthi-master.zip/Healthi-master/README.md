# Healthi
Healthi project utilsis 
This is a Project under development, the aim of the project is to connect patients and health providers and decentralization of information
